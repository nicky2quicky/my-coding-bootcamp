# Code Drills
[Back to Course Guidelines](../../README.md#course-guidelines)

### Code Drills Completion Minimum

Please see each `Code Drill` resource for each Module. 

Required Code Drills are expected to be completed incrementally but will be checked during project one, project two, and project tree. 

Code Drills should be organized on a student owned github repository. 

Code Drills will be peer reviewed.
