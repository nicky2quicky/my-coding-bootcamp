* Remember to close your tags by adding a tag prepended with `/`!
    ```
    <h1>This is a h1 tag that is closed!</h1>
    ```

* Use the `<title>` tag to define the name of the webpage

* Use the `<h1>` through `<h6>` tags to create your headers

* The `<strong>` tag is used to bold text within html
