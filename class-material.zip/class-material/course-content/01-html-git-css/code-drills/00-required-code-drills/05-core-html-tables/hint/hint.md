* You can use the `<thead>` tag to indicate what you want as the header to your table, and the `<tbody>` tag to indicate what you want as the body of your table.

* Pay attention to the order you create the `<th>` and the `<td>` tags. Order matters!

* Remember to put the anchor tags around the elements you want to make a link!